# mosaicRS

This is mosaicRS, a retrieval system library for mosaic (or other data sources).

### Future features:
- Retrieval Augmented Generation (RAG)
- Conversational search
- Topic modelling
- Summarized results

A working implementation including a web-interface can be found as mosaic-rs-service


## Dev infos

